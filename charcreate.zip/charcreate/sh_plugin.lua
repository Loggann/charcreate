local PLUGIN = PLUGIN or {}
PLUGIN.name = "CharCreate"
PLUGIN.author = "Robert Bearson"
PLUGIN.desc = ""
PLUGIN.view = {}

--Materials
resource.AddFile("materials/themis/mafiarp.png")
resource.AddFile("materials/themis/logotype.png")

PLUGIN.mafiaTitle = Material("themis/mafiarp.png")
--[[ old
PLUGIN.cMdlPos = "setpos 931.794067 2898.348877 1024;setang 3.453128 92.476685 0.000000"
PLUGIN.camPos = {
  character = "setpos 901.407532 3044.660889 1113.079834;setang 11.538097 -83.864960 0.000000",
  backDrop = "setpos 929.155945 3977.735596 1702.879272;setang -0.396909 -88.181007 0.000000"
}
]]
PLUGIN.cMdlPos = "setpos -6553.514648 6358.729980 8727.212891;setang 13.811789 88.812035 0.000000"
PLUGIN.camPos = {
  character = "setpos -6526.331543 8684.434570 8459.932617;setang 1.559979 -90.359756 0.000000",
  backDrop = "setpos -6553.514648 6358.729980 8727.212891;setang 13.811789 88.812035 0.000000"
}

PLUGIN.defaultFaction = FACTION_citizen

--Sound Corner
resource.AddFile("sound/typhon/ui_click.mp3")
resource.AddFile("sound/typhon/ui_hover.mp3")
PLUGIN.hoverSound = "typhon/ui_hover.mp3"
PLUGIN.clickSound = "typhon/ui_click.mp3"

--Other Files
nut.util.include("cl_plugin.lua")

--Animation
local cinematic = {
  settings = {
    animName = "intro",
    baseTime = 8,
    loopAnim = true,
		fadeTime = 3,
		showSkipButton = false,
		skipButtonColor = Color(43, 37, 37),
		map = "rp_berlin_themis_v1"
  },
  points = {
    
  }
}
